package com.problem;

import java.util.Random;

public class TestMedicine {

	public static void main(String[] args) {
		MedicineInfo info[] = new MedicineInfo[10];
		Random rand = new Random();
		int num = 0;
		for (int i = 0; i < info.length; i++) {
			num = rand.nextInt(3);
			if(num == 0) {
				info[i] = new Tablet("Tech Pharmaceuticals","Pune");
			} else if(num == 1) {
				info[i] = new Syrup("Mahindra Pharmaceuticals","Nagpur");
			} else {
				info[i] = new Ointment("MBT Pharmaceuticals","Mumbai");
			}
			
			info[i].displayLable1();
			System.out.println();
		}

	}

}
