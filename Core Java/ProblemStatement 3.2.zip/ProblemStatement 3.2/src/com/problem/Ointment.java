package com.problem;

public class Ointment extends MedicineInfo {

	Ointment(String x, String y) {
		super(x, y);
	}
	
	public void displayLable1() {
		super.displayLable1();
		System.out.println("For external use only");
	}

}
