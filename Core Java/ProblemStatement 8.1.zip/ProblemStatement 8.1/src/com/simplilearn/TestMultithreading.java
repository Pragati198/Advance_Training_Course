package com.simplilearn;

import com.simplilearn.counter.Counter;
import com.simplilearn.printer.Printer;
import com.simplilearn.storage.Storage;

public class TestMultithreading {
public static void main(String[] args) {
		
		Storage storage = new Storage();
		
		Counter counter = new Counter(storage);
		
		Printer printer = new Printer(storage);
		
		counter.addValues();
		
		if(!Storage.flag) {
			
			
			synchronized (storage) {
				
				try {
					storage.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		}
		printer.readValues();


	}



}
