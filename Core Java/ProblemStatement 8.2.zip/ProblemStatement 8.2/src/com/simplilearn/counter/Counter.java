package com.simplilearn.counter;

public class Counter {

}
