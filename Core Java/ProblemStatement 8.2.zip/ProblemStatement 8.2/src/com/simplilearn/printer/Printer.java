package com.simplilearn.printer;

public class Printer {

}
