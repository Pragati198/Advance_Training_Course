package com.simplilearn.storage;

import java.util.ArrayList;
import java.util.List;

public class Storage {
public static boolean flag = false;
	
	private static List<Integer> listOfNumbers = new ArrayList<>();
	
	public static  void storeValues(Integer num) {
		
		listOfNumbers.add(num);
	}
	
	public  void readValues() {
		
		for(Integer val:listOfNumbers) {
			System.out.print(val+" ");

		}
	}



}
