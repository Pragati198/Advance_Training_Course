package com.rectangle;

import java.util.Scanner;

public class TestRectangle {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter length of rectangle 1 :");
		float length1 = sc.nextFloat();
		System.out.println("Enter breadth of rectangle 1 :");
		float breadth1 = sc.nextFloat();
		Rectangle r1 = new Rectangle(length1,breadth1);
		System.out.println("Area of rectangle 1 is :" + r1.calculateArea());
		
		System.out.println("-----------------------------------------------------");

		
		System.out.println("Enter length of rectangle 2 :");
		float length2 = sc.nextFloat();
		System.out.println("Enter breadth of rectangle 2 :");
		float breadth2 = sc.nextFloat();
		Rectangle r2 = new Rectangle(length2,breadth2);
		System.out.println("Area of rectangle 2 is :" + r2.calculateArea());
		
		System.out.println("-----------------------------------------------------");
		
		System.out.println("Enter length of rectangle 3 :");
		float length3 = sc.nextFloat();
		System.out.println("Enter breadth of rectangle 3 :");
		float breadth3 = sc.nextFloat();
		Rectangle r3 = new Rectangle(length3,breadth3);
		System.out.println("Area of rectangle 3 is :" + r3.calculateArea());
		
		System.out.println("-----------------------------------------------------");
		
		System.out.println("Enter length of rectangle 4 :");
		float length4 = sc.nextFloat();
		System.out.println("Enter breadth of rectangle 4 :");
		float breadth4 = sc.nextFloat();
		Rectangle r4 = new Rectangle(length4,breadth4);
		System.out.println("Area of rectangle 4 is :" + r4.calculateArea());
		
		System.out.println("-----------------------------------------------------");
		
		System.out.println("Enter length of rectangle 5 :");
		float length5 = sc.nextFloat();
		System.out.println("Enter breadth of rectangle 5 :");
		float breadth5 = sc.nextFloat();
		Rectangle r5 = new Rectangle(length5,breadth5);
		System.out.println("Area of rectangle 5 is :" + r5.calculateArea());

	}


}
