package com.book;

public class Book {

	private String bookTitle;
	private double bookPrice;

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(String bookTitle, double bookPrice) {
		super();
		this.bookTitle = bookTitle;
		this.bookPrice = bookPrice;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public void display() {
		System.out.println("Book Title " + this.bookTitle);
		System.out.println("Book Price " + this.bookPrice);
	}


}
