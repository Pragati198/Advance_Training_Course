package com.mycompany.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {public static Connection dbConn() throws ClassNotFoundException, SQLException {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb", "root", "Tiger");
	return con;
}


}
